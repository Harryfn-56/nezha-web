/**
 * TRANG QUẢN TRỊ CỦA GIÁO VIÊN
 * 4 thẻ: Bảng điểm · Lớp học · Bài học (tải file Word/PDF) · Kết nối
 */

import { el, mount, go, toast, fmtDate, clear, append } from '../core.js';
import { GAMES } from '../data.js';
import { CONFIG } from '../config.js';
import {
  currentUser, allScores, buildReport, listClasses, addClass, removeClass,
  listLessons, saveLesson, deleteLesson, pingCloud, CLOUD,
  listTeachers, saveTeacher, removeTeacher, canSeeClass, assignClassToSelf,
  listStudents, addStudent, addStudents, removeStudent,
} from '../store.js';
import { extractText, parseVocab, buildLesson } from '../importer.js';
import { page } from './layout.js';

export async function view() {
  const u = currentUser();
  if (!u || u.role !== 'teacher') return go('/', true);

  const isAdmin = !!u.isAdmin;
  const panel = el('div');

  const tabs = [
    ['scores', '📊 Bảng điểm'],
    ['students', '🎒 Học sinh'],
    ['classes', '🏫 Lớp học'],
    ['lessons', '📚 Bài học'],
    ...(isAdmin ? [['teachers', '👩‍🏫 Giáo viên'], ['cloud', '☁️ Kết nối']] : []),
  ];

  let tab = sessionStorage.getItem('nz_admin_tab') || 'scores';
  if (!tabs.some(([id]) => id === tab)) tab = 'scores';

  const tabBar = el('div.seg.seg-scroll', { style: { maxWidth: '760px' } },
    tabs.map(([id, label]) => el('button' + (tab === id ? '.on' : ''), {
      onclick: () => {
        tab = id;
        sessionStorage.setItem('nz_admin_tab', id);
        Array.from(tabBar.children).forEach((b, i) => b.classList.toggle('on', tabs[i][0] === id));
        draw();
      },
    }, label))
  );

  function draw() {
    clear(panel);
    if (tab === 'scores') renderScores(panel, u);
    else if (tab === 'students') renderStudents(panel, u);
    else if (tab === 'classes') renderClasses(panel, u);
    else if (tab === 'lessons') renderLessons(panel);
    else if (tab === 'teachers') renderTeachers(panel);
    else renderCloud(panel);
  }

  mount(page(el('div.wrap.stack', { style: { '--gap': '20px' } }, [
    el('div.row-between.wrapf', {}, [
      el('div', {}, [
        el('h1', { style: { marginBottom: '2px' } }, 'Trang quản trị'),
        el('p.muted.mb-0', {}, isAdmin
          ? 'Quản trị viên — xem được tất cả các lớp và cấp tài khoản cho giáo viên'
          : `Xin chào ${u.name} — thầy/cô đang xem ${(u.classes || []).length
              ? 'lớp: ' + (u.classes || []).join(', ') : 'lớp được phân công'}`),
      ]),
      el('a.btn.btn-orange', { href: '/live', 'data-link': '' }, '⚡ Mở phòng Kahoot'),
    ]),
    tabBar,
    panel,
  ])));

  draw();
}

/* ==================================================================== */
/*  Thẻ 1 — Bảng điểm                                                   */
/* ==================================================================== */

const PERIODS = [
  ['', 'Từ trước tới nay'],
  ['7', '7 ngày gần đây'],
  ['30', '30 ngày gần đây'],
  ['1', 'Hôm nay'],
];

async function renderScores(host, user) {
  host.append(el('div.card.center', { style: { minHeight: '120px' } }, 'Đang tải dữ liệu...'));

  const [allClasses, allRows, allStudents] = await Promise.all([
    listClasses(), allScores(), listStudents(),
  ]);

  // Giáo viên thường chỉ thấy lớp mình phụ trách
  const classes = allClasses.filter((c) => canSeeClass(user, c.code));
  const rows = allRows.filter((r) => canSeeClass(user, r.class_code));
  const roster = allStudents.filter((s) => canSeeClass(user, s.class_code));

  if (!user.isAdmin && !classes.length) {
    clear(host);
    host.append(el('div.card.empty', {}, [
      el('div.ic', {}, '🔒'),
      el('div.bold', {}, 'Thầy/cô chưa có lớp nào'),
      el('div.small', {}, 'Sang thẻ "🏫 Lớp học" để tự tạo lớp của mình, hoặc nhờ quản trị viên gán lớp cho tài khoản này.'),
    ]));
    return;
  }

  let filterClass = '';
  let filterGame = '';
  let filterDays = '';
  let filterStudent = '';        // '' = cả lớp, hoặc id của 1 em

  const body = el('div');
  const studentSel = el('select.input', {
    style: { maxWidth: '260px' },
    onchange: (e) => { filterStudent = e.target.value; refresh(); },
  });

  /**
   * Danh sách em có thể chọn: danh sách lớp + những em có điểm nhưng không
   * còn trong danh sách (bị đổi tên/xoá tên) để thầy/cô vẫn xem lại được.
   */
  function pickList() {
    const inScope = (code) => !filterClass || code === filterClass;
    const map = new Map();
    for (const s of roster) {
      if (inScope(s.class_code)) map.set(s.id, s);
    }
    for (const r of rows) {
      if (!inScope(r.class_code) || map.has(r.student_id)) continue;
      map.set(r.student_id, { id: r.student_id, name: r.student_name, class_code: r.class_code });
    }
    return Array.from(map.values()).sort((a, b) => a.name.localeCompare(b.name, 'vi'));
  }

  /** Ô chọn học sinh — chỉ liệt kê các em thuộc lớp đang xem */
  function fillStudentSel() {
    const list = pickList();
    clear(studentSel);
    const n = roster.filter((s) => !filterClass || s.class_code === filterClass).length;
    studentSel.append(
      el('option', { value: '' }, `👥 Cả lớp (${n || list.length} em)`),
      ...list.map((s) => el('option', {
        value: s.id, selected: s.id === filterStudent ? true : null,
      }, `${s.name}${filterClass ? '' : ' — ' + s.class_code}`)),
    );
    if (!list.some((s) => s.id === filterStudent)) filterStudent = '';
  }

  function refresh() {
    fillStudentSel();

    /* --- lọc dữ liệu theo 4 bộ lọc --- */
    let data = rows;
    if (filterClass) data = data.filter((r) => r.class_code === filterClass);
    if (filterGame) data = data.filter((r) => r.game_id === filterGame);
    if (filterDays) {
      const from = Date.now() - Number(filterDays) * 24 * 3600 * 1000;
      data = data.filter((r) => new Date(r.played_at).getTime() >= from);
    }

    const scopeRoster = roster.filter((s) => !filterClass || s.class_code === filterClass);
    const me = filterStudent ? pickList().find((s) => s.id === filterStudent) : null;
    if (me) data = data.filter((r) => r.student_id === me.id || r.student_name === me.name);

    const rep = buildReport(data, me ? [me] : scopeRoster);
    const board = rep.done;
    const periodLabel = (PERIODS.find(([v]) => v === filterDays) || PERIODS[0])[1].toLowerCase();

    clear(body);
    append(body, [
      me ? studentHeader(me, rep) : classHeader(rep, scopeRoster, periodLabel),

      /* ---------- Ai chưa làm bài ---------- */
      rep.todo.length ? el('div.card.card-warn', { style: { marginBottom: '18px' } }, [
        el('div.row-between.wrapf', {}, [
          el('h3', { style: { marginBottom: '4px' } },
            `⏳ ${rep.todo.length} em chưa làm bài (${periodLabel})`),
          el('button.btn.btn-ghost.btn-sm', {
            onclick: () => copyNames(rep.todo),
          }, '📋 Chép danh sách'),
        ]),
        el('div.row.wrapf', { style: { gap: '7px', marginTop: '8px' } },
          rep.todo.map((s) => el('span.chip.chip-warn', {},
            filterClass ? s.name : `${s.name} · ${s.classCode}`))),
      ]) : (scopeRoster.length && !me ? el('div.alert.alert-ok', { style: { marginBottom: '18px' } },
        `🎉 Cả ${scopeRoster.length} em trong danh sách đều đã làm bài ${periodLabel}.`) : null),

      /* ---------- Chính xác theo trò chơi ---------- */
      el('div.sec-title', {}, [
        el('h2', {}, me ? `🎮 ${me.name} làm từng trò thế nào` : '🎮 Đúng bao nhiêu % ở mỗi trò chơi'),
        el('div.ln'),
      ]),
      rep.byGame.length ? el('div.card', {}, [
        el('div.small.muted', { style: { marginBottom: '12px' } },
          'Xếp từ trò làm kém nhất lên trên — đó là chỗ nên ôn thêm.'),
        ...rep.byGame.map((g) => {
          const info = GAMES.find((x) => x.id === g.key);
          return meter(
            `${info ? info.icon + ' ' + info.name : g.key}`,
            g.accuracy,
            `${g.correct}/${g.total} câu · ${g.plays} lượt${me ? '' : ` · ${g.students} em`}`,
          );
        }),
      ]) : el('div.card.empty', {}, [
        el('div.ic', {}, '🎮'),
        el('div.bold', {}, 'Chưa có lượt chơi nào trong khoảng này'),
      ]),

      /* ---------- Trò chưa thử (chỉ khi xem 1 em) ---------- */
      me ? untriedGames(rep) : null,

      /* ---------- Hay sai ở đâu ---------- */
      el('div.sec-title', {}, [el('h2', {}, '❌ Hay sai ở đâu'), el('div.ln')]),
      rep.mistakes.length ? el('div', {}, [
        el('div.tbl-wrap', {}, el('table.tbl', {}, [
          el('thead', {}, el('tr', {}, [
            el('th', { style: { width: '54px' } }, '#'),
            el('th', {}, 'Từ'), el('th', {}, 'Pinyin'), el('th', {}, 'Nghĩa'),
            el('th', {}, 'Số lần sai'),
            ...(me ? [] : [el('th', {}, 'Bao nhiêu em sai')]),
            el('th', {}, 'Sai ở trò'),
          ])),
          el('tbody', {}, rep.mistakes.slice(0, 25).map((w, i) => el('tr', {}, [
            el('td.rank', {}, String(i + 1)),
            el('td', {}, el('span.hz', { style: { fontSize: '1.35rem' } }, w.hz)),
            el('td.small', {}, w.py || '—'),
            el('td.bold', {}, w.vi || '—'),
            el('td.bold', { style: { color: 'var(--bad)' } }, String(w.n)),
            ...(me ? [] : [el('td', {}, `${w.students} em`)]),
            el('td', {}, el('div.row.wrapf', { style: { gap: '4px' } },
              w.games.slice(0, 4).map((id) => {
                const g = GAMES.find((x) => x.id === id);
                return el('span.chip.chip-soft', { title: g ? g.name : id }, g ? g.icon : '?');
              }))),
          ]))),
        ])),
        el('button.btn.btn-ghost.btn-sm', {
          style: { marginTop: '12px' },
          onclick: () => exportMistakesCsv(rep.mistakes, me),
        }, '⬇️ Tải danh sách từ hay sai (CSV)'),
      ]) : el('div.card.empty', {}, [
        el('div.ic', {}, '✅'),
        el('div.bold', {}, 'Chưa ghi nhận từ sai nào'),
        el('div.small', {}, 'Mục này lấy dữ liệu từ những lượt chơi mới (bản 1.6 trở đi). Các lượt chơi cũ không có chi tiết từ sai nên chưa hiện ở đây.'),
      ]),

      /* ---------- Bảng điểm học sinh ---------- */
      me ? null : el('div.sec-title', {}, [el('h2', {}, '🏆 Bảng điểm học sinh'), el('div.ln')]),
      me ? null : (board.length ? el('div.tbl-wrap', {}, el('table.tbl', {}, [
        el('thead', {}, el('tr', {}, [
          el('th', {}, '#'), el('th', {}, 'Học sinh'), el('th', {}, 'Lớp'),
          el('th', {}, 'Lượt chơi'), el('th', {}, 'Trò đã thử'),
          el('th', {}, 'Câu đúng'), el('th', {}, 'Chính xác'),
          el('th', {}, 'Tổng điểm'), el('th', {}, 'Lần gần nhất'), el('th', {}, ''),
        ])),
        el('tbody', {}, board.map((s, i) => el('tr', {}, [
          el('td.rank', {}, i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : String(i + 1)),
          el('td.bold', {}, s.name),
          el('td', {}, el('span.chip.chip-soft', {}, s.classCode || '—')),
          el('td', {}, String(s.plays)),
          el('td', {}, `${s.games}/${GAMES.length}`),
          el('td', {}, `${s.correct}/${s.total}`),
          el('td', {}, el('span', {
            style: { color: accColor(s.accuracy), fontWeight: 700 },
          }, s.accuracy + '%')),
          el('td.bold', { style: { color: 'var(--red-700)' } }, s.totalScore.toLocaleString('vi-VN')),
          el('td.small.muted', {}, s.last ? fmtDate(s.last) : '—'),
          el('td', {}, el('button.btn.btn-ghost.btn-sm', {
            title: `Xem riêng số liệu của ${s.name}`,
            onclick: () => {
              filterStudent = s.id;
              refresh();
              body.scrollIntoView({ behavior: 'smooth', block: 'start' });
            },
          }, '🔍 Xem')),
        ]))),
      ])) : el('div.card.empty', {}, [
        el('div.ic', {}, '📭'),
        el('div.bold', {}, 'Chưa có dữ liệu'),
        el('div.small', {},
          CLOUD ? 'Học sinh chơi xong sẽ hiện ở đây.'
                : 'Đang ở chế độ ngoại tuyến — chỉ thấy dữ liệu trên chính máy này. Bật Supabase ở thẻ "Kết nối" để xem điểm của cả lớp.'),
      ])),

      el('div.row.wrapf', { style: { marginTop: '14px' } }, [
        el('button.btn.btn-ghost.btn-sm', { onclick: () => exportCsv(data) }, '⬇️ Tải file Excel (CSV)'),
        el('button.btn.btn-ghost.btn-sm', { onclick: () => window.print() }, '🖨️ In bảng điểm'),
      ]),

      /* ---------- Chi tiết từng lượt chơi ---------- */
      el('div.sec-title', {}, [el('h2', {}, '🕒 Chi tiết từng lượt chơi'), el('div.ln')]),
      el('div.tbl-wrap', {}, el('table.tbl', {}, [
        el('thead', {}, el('tr', {}, [
          el('th', {}, 'Thời gian'), el('th', {}, 'Học sinh'), el('th', {}, 'Lớp'),
          el('th', {}, 'Trò chơi'), el('th', {}, 'Đúng'), el('th', {}, 'Điểm'), el('th', {}, 'Từ sai'),
        ])),
        el('tbody', {}, data.slice(0, 100).map((r) => {
          const g = GAMES.find((x) => x.id === r.game_id);
          const ws = Array.isArray(r.wrong_words) ? r.wrong_words : [];
          const acc = r.total_count ? Math.round((r.correct_count / r.total_count) * 100) : 0;
          return el('tr', {}, [
            el('td.small.muted', {}, fmtDate(r.played_at)),
            el('td', {}, r.student_name),
            el('td.small', {}, r.class_code),
            el('td', {}, g ? `${g.icon} ${g.name}` : r.game_id),
            el('td', {}, el('span', { style: { color: accColor(acc), fontWeight: 700 } },
              `${r.correct_count}/${r.total_count}`)),
            el('td.bold', {}, String(r.score)),
            el('td.small.muted', { style: { maxWidth: '220px' } },
              ws.length ? ws.slice(0, 6).map((w) => w.hz).join(' ') + (ws.length > 6 ? ' …' : '') : '—'),
          ]);
        })),
      ])),
    ]);
  }

  clear(host);
  host.append(
    el('div.card', { style: { marginBottom: '18px', padding: '14px 16px' } },
      el('div.row.wrapf', { style: { alignItems: 'flex-end' } }, [
        el('label.field', { style: { marginBottom: 0, minWidth: '190px' } }, [
          el('span', {}, 'Lớp'),
          el('select.input', {
            onchange: (e) => { filterClass = e.target.value; filterStudent = ''; refresh(); },
          }, [el('option', { value: '' }, '🏫 Tất cả lớp'),
              ...classes.map((c) => el('option', { value: c.code }, `${c.code} — ${c.name}`))]),
        ]),
        el('label.field', { style: { marginBottom: 0, minWidth: '210px' } }, [
          el('span', {}, 'Xem của ai'), studentSel,
        ]),
        el('label.field', { style: { marginBottom: 0, minWidth: '200px' } }, [
          el('span', {}, 'Trò chơi'),
          el('select.input', {
            onchange: (e) => { filterGame = e.target.value; refresh(); },
          }, [el('option', { value: '' }, '🎮 Tất cả trò chơi'),
              ...GAMES.map((g) => el('option', { value: g.id }, `${g.icon} ${g.name}`))]),
        ]),
        el('label.field', { style: { marginBottom: 0, minWidth: '170px' } }, [
          el('span', {}, 'Khoảng thời gian'),
          el('select.input', {
            onchange: (e) => { filterDays = e.target.value; refresh(); },
          }, PERIODS.map(([v, t]) => el('option', { value: v }, '📅 ' + t))),
        ]),
      ])),
    body,
  );
  refresh();
}

/* ---------- các mảnh giao diện của thẻ Bảng điểm ---------- */

const accColor = (a) =>
  a >= 80 ? 'var(--ok)' : a >= 60 ? 'var(--orange-600)' : 'var(--bad)';

/** Thanh đo tỉ lệ đúng của 1 trò chơi */
function meter(label, pct, sub) {
  return el('div.meter', {}, [
    el('div.meter-top', {}, [
      el('span.meter-label', {}, label),
      el('span.meter-pct', { style: { color: accColor(pct) } }, pct + '%'),
    ]),
    el('div.meter-track', {}, el('i', {
      style: { width: Math.max(2, pct) + '%', background: accColor(pct) },
    })),
    el('div.meter-sub', {}, sub),
  ]);
}

/** Dải số liệu khi đang xem CẢ LỚP */
function classHeader(rep, scopeRoster, periodLabel) {
  const n = scopeRoster.length;
  const doneN = rep.done.length;
  const pct = n ? Math.round((doneN / n) * 100) : 0;
  const weakest = rep.byGame[0];
  const wName = weakest
    ? (GAMES.find((g) => g.id === weakest.key) || {}).name || weakest.key : '';

  return el('div', { style: { marginBottom: '18px' } }, [
    el('div.stat-row', { style: { marginBottom: '14px' } }, [
      adminStat('✅', 'Đã làm bài', n ? `${doneN}/${n}` : String(doneN)),
      adminStat('🎮', 'Lượt chơi', String(rep.plays)),
      adminStat('🎯', 'Chính xác chung', rep.accuracy + '%'),
      weakest
        ? adminStat('📉', 'Trò yếu nhất — ' + wName, weakest.accuracy + '%')
        : adminStat('📉', 'Trò yếu nhất', '—'),
    ]),
    n ? el('div.card', { style: { padding: '14px 16px' } }, [
      el('div.row-between', { style: { marginBottom: '8px' } }, [
        el('span.bold', {}, `Tiến độ làm bài của lớp`),
        el('span.bold', { style: { color: accColor(pct) } }, `${pct}%`),
      ]),
      el('div.meter-track', { style: { height: '14px' } }, el('i', {
        style: { width: Math.max(2, pct) + '%', background: accColor(pct) },
      })),
      el('div.small.muted', { style: { marginTop: '8px' } },
        `${doneN} em đã làm · ${rep.todo.length} em chưa làm · tổng ${n} em trong danh sách lớp`),
    ]) : el('div.alert.alert-info', {},
      'Chưa nhập danh sách học sinh nên chưa biết em nào chưa làm bài. Sang thẻ "🎒 Học sinh" nhập danh sách lớp trước nhé.'),
  ]);
}

/** Dải số liệu khi đang xem RIÊNG 1 EM */
function studentHeader(me, rep) {
  const s = rep.done[0];
  return el('div', { style: { marginBottom: '18px' } }, [
    el('div.card', { style: { marginBottom: '14px' } }, [
      el('div.row.wrapf', { style: { alignItems: 'center' } }, [
        el('div.ic-badge', { style: { fontSize: '1.5rem' } }, '🎒'),
        el('div.grow', {}, [
          el('h2', { style: { marginBottom: '2px' } }, me.name),
          el('div.small.muted', {}, `Lớp ${me.class_code || me.classCode || '—'}`),
        ]),
        s ? el('span.chip', {}, `Lần gần nhất: ${s.last ? fmtDate(s.last) : '—'}`)
          : el('span.chip.chip-warn', {}, '⏳ Chưa làm bài lần nào'),
      ]),
    ]),
    el('div.stat-row', {}, [
      adminStat('🎮', 'Lượt chơi', String(rep.plays)),
      adminStat('🎯', 'Chính xác', rep.accuracy + '%'),
      adminStat('✏️', 'Câu đúng', `${rep.correct}/${rep.total}`),
      adminStat('🏆', 'Tổng điểm', s ? s.totalScore.toLocaleString('vi-VN') : '0'),
    ]),
  ]);
}

/** Những trò em đó chưa thử lần nào */
function untriedGames(rep) {
  const played = new Set(rep.byGame.map((g) => g.key));
  const left = GAMES.filter((g) => !played.has(g.id));
  if (!left.length) {
    return el('div.alert.alert-ok', { style: { marginTop: '12px' } },
      '🎉 Em này đã thử hết các trò chơi.');
  }
  return el('div.card', { style: { marginTop: '12px' } }, [
    el('div.bold', {}, `🕹️ Chưa thử ${left.length} trò`),
    el('div.row.wrapf', { style: { gap: '7px', marginTop: '8px' } },
      left.map((g) => el('span.chip.chip-soft', {}, `${g.icon} ${g.name}`))),
  ]);
}

function copyNames(list) {
  const text = list.map((s) => s.name).join('\n');
  try {
    navigator.clipboard.writeText(text);
    toast(`Đã chép ${list.length} tên vào bộ nhớ tạm`, 'ok');
  } catch { toast('Trình duyệt không cho chép tự động', 'bad'); }
}

function exportMistakesCsv(mistakes, me) {
  const lines = ['STT,Hán tự,Pinyin,Nghĩa,Số lần sai,Số em sai'];
  mistakes.forEach((w, i) => lines.push(
    `${i + 1},"${w.hz}","${w.py || ''}","${w.vi || ''}",${w.n},${w.students}`));
  const blob = new Blob(['\uFEFF' + lines.join('\n')], { type: 'text/csv;charset=utf-8' });
  const a = el('a', {
    href: URL.createObjectURL(blob),
    download: `tu-hay-sai-${me ? me.name.replace(/\s+/g, '-') : 'ca-lop'}.csv`,
  });
  a.click();
  toast('Đã tải danh sách từ hay sai', 'ok');
}

function exportCsv(rows) {
  const head = ['Thời gian', 'Học sinh', 'Lớp', 'Bài', 'Trò chơi', 'Câu đúng', 'Tổng câu',
    '% đúng', 'Điểm', 'Giây', 'Từ sai'];
  const lines = [head.join(',')];
  for (const r of rows) {
    const g = GAMES.find((x) => x.id === r.game_id);
    const acc = r.total_count ? Math.round((r.correct_count / r.total_count) * 100) : 0;
    const ws = (Array.isArray(r.wrong_words) ? r.wrong_words : [])
      .map((w) => w.hz).join(' ');
    lines.push([
      `"${fmtDate(r.played_at)}"`, `"${r.student_name}"`, r.class_code, r.lesson_id,
      `"${g ? g.name : r.game_id}"`, r.correct_count, r.total_count, acc, r.score,
      Math.round((r.duration_ms || 0) / 1000), `"${ws}"`,
    ].join(','));
  }
  // BOM để Excel mở đúng tiếng Việt
  const blob = new Blob(['\uFEFF' + lines.join('\n')], { type: 'text/csv;charset=utf-8' });
  const a = el('a', { href: URL.createObjectURL(blob), download: `diem-nezha-${Date.now()}.csv` });
  a.click();
  toast('Đã tải file CSV', 'ok');
}

/** Ô thống kê của trang quản trị (vỏ ngoài + lõi trong + biểu tượng) */
function adminStat(icon, k, v) {
  return el('div.stat', {}, el('div.stat-in', {}, [
    el('div.ic-badge', {}, icon),
    el('div.grow', {}, [el('div.k', {}, k), el('div.v', {}, v)]),
  ]));
}

/* ==================================================================== */
/*  Thẻ — Danh sách học sinh (chỉ giáo viên được thêm tài khoản)        */
/* ==================================================================== */

const STU_CLASS_KEY = 'nz_admin_class';

async function renderStudents(host, user) {
  const all = await listClasses();
  const classes = all.filter((c) => canSeeClass(user, c.code));

  if (!classes.length) {
    clear(host);
    host.append(el('div.card.empty', {}, [
      el('div.ic', {}, '🏫'),
      el('div.bold', {}, 'Chưa có lớp nào'),
      el('div.small', {}, 'Sang thẻ "🏫 Lớp học" để tạo lớp trước, rồi quay lại đây thêm học sinh.'),
    ]));
    return;
  }

  let code = sessionStorage.getItem(STU_CLASS_KEY) || '';
  if (!classes.some((c) => c.code === code)) code = classes[0].code;

  const students = await listStudents(code);
  const oneName = el('input.input', { placeholder: 'VD: Nguyễn Minh An' });
  const bulk = el('textarea.input', {
    rows: 6,
    placeholder: 'Dán cả danh sách vào đây, mỗi dòng một tên:\n\nNguyễn Minh An\nTrần Bảo Ngọc\nLê Gia Hân',
  });

  const classSel = el('select.input', {
    style: { maxWidth: '280px' },
    onchange: (e) => {
      sessionStorage.setItem(STU_CLASS_KEY, e.target.value);
      renderStudents(host, user);
    },
  }, classes.map((c) => el('option', {
    value: c.code, selected: c.code === code ? true : null,
  }, `${c.code} — ${c.name}`)));

  clear(host);
  host.append(
    el('div.alert.alert-info', { style: { marginBottom: '16px' } }, [
      el('div.bold', {}, '🔐 Chỉ học sinh có tên trong danh sách này mới đăng nhập được'),
      el('div.small', {}, 'Học sinh gõ đúng họ tên (không cần đúng dấu) + mã lớp là vào học. Tên lạ sẽ bị từ chối, nên không ai tự tạo tài khoản để chơi trước xem đáp án.'),
    ]),

    el('div.row.wrapf', { style: { marginBottom: '16px', alignItems: 'flex-end' } }, [
      el('label.field', { style: { marginBottom: 0 } }, [el('span', {}, 'Đang xem lớp'), classSel]),
      el('span.chip', {}, `${students.length} học sinh`),
    ]),

    el('div.card', { style: { marginBottom: '18px' } }, [
      el('h3', {}, '➕ Thêm học sinh'),
      el('div.row.wrapf', { style: { alignItems: 'flex-end' } }, [
        el('label.field.grow', { style: { marginBottom: 0, minWidth: '220px' } },
          [el('span', {}, 'Họ và tên'), oneName]),
        el('button.btn', {
          onclick: async () => {
            try {
              const r = await addStudent(code, oneName.value);
              toast(`Đã thêm ${r.name} vào lớp ${code}`, 'ok');
              renderStudents(host, user);
            } catch (e) { toast(e.message, 'bad'); }
          },
        }, 'Thêm'),
      ]),

      el('div.row', { style: { margin: '16px 0 8px' } }, [
        el('div', { style: { flex: 1, height: '1px', background: 'var(--line)' } }),
        el('span.small.muted', {}, 'hoặc thêm cả danh sách'),
        el('div', { style: { flex: 1, height: '1px', background: 'var(--line)' } }),
      ]),

      el('label.field', {}, [el('span', {}, 'Dán danh sách lớp'), bulk]),
      el('button.btn.btn-block', {
        onclick: async () => {
          if (!bulk.value.trim()) return toast('Chưa có tên nào', 'bad');
          const added = await addStudents(code, bulk.value);
          toast(`Đã thêm ${added.length} học sinh vào lớp ${code}`, 'ok');
          renderStudents(host, user);
        },
      }, '📋 Thêm cả danh sách'),
    ]),

    el('div.sec-title', {}, [el('h2', {}, `🎒 Học sinh lớp ${code}`), el('div.ln')]),

    students.length ? el('div.tbl-wrap', {}, el('table.tbl', {}, [
      el('thead', {}, el('tr', {}, [
        el('th', { style: { width: '52px' } }, '#'),
        el('th', {}, 'Họ và tên'),
        el('th', {}, 'Đăng nhập bằng'),
        el('th', {}, ''),
      ])),
      el('tbody', {}, students.map((s, i) => el('tr', {}, [
        el('td', {}, String(i + 1)),
        el('td.bold', {}, s.name),
        el('td.small.muted', {}, `${s.name} + ${code}`),
        el('td', {}, el('button.btn.btn-plain.btn-sm', {
          onclick: async () => {
            if (!confirm(`Xoá ${s.name} khỏi lớp ${code}? Em này sẽ không đăng nhập được nữa.`)) return;
            await removeStudent(s.id);
            toast('Đã xoá ' + s.name);
            renderStudents(host, user);
          },
        }, '🗑️')),
      ]))),
    ])) : el('div.card.empty', {}, [
      el('div.ic', {}, '🎒'),
      el('div.bold', {}, 'Lớp này chưa có học sinh nào'),
      el('div.small', {}, 'Chưa thêm tên thì chưa em nào đăng nhập được. Dán danh sách lớp vào ô phía trên là nhanh nhất.'),
    ]),

    students.length ? el('div.row.wrapf', { style: { marginTop: '14px' } }, [
      el('button.btn.btn-ghost.btn-sm', {
        onclick: () => exportStudentsCsv(code, students),
      }, '⬇️ Tải danh sách (CSV)'),
      el('button.btn.btn-ghost.btn-sm', { onclick: () => window.print() }, '🖨️ In danh sách'),
    ]) : null,

    !CLOUD ? el('div.alert', { style: { marginTop: '16px' } },
      '⚠️ Đang ở chế độ ngoại tuyến: danh sách này chỉ nằm trên máy đang dùng, máy của học sinh chưa thấy. Bật Supabase ở thẻ "Kết nối" để cả trung tâm dùng chung.') : null,
  );
}

function exportStudentsCsv(code, students) {
  const lines = ['STT,Họ và tên,Mã lớp'];
  students.forEach((s, i) => lines.push(`${i + 1},"${s.name}",${code}`));
  const blob = new Blob(['\uFEFF' + lines.join('\n')], { type: 'text/csv;charset=utf-8' });
  const a = el('a', { href: URL.createObjectURL(blob), download: `hoc-sinh-${code}.csv` });
  a.click();
  toast('Đã tải danh sách lớp ' + code, 'ok');
}

/* ==================================================================== */
/*  Thẻ 2 — Lớp học                                                     */
/* ==================================================================== */

async function renderClasses(host, user) {
  const isAdmin = !!user.isAdmin;
  const all = await listClasses();
  const classes = isAdmin ? all : all.filter((c) => canSeeClass(user, c.code));

  const code = el('input.input', { placeholder: 'VD: TH2002', style: { textTransform: 'uppercase' } });
  const name = el('input.input', { placeholder: 'VD: Lớp thiếu nhi thứ 3-5' });

  clear(host);
  host.append(
    el('div.alert.alert-info', { style: { marginBottom: '16px' } },
      'Mã lớp chính là mật khẩu của học sinh. Học sinh gõ họ tên + mã lớp để vào học.'),

    el('div.card', { style: { marginBottom: '18px' } }, [
      el('h3', {}, '➕ Thêm lớp mới'),
      el('div.row.wrapf', { style: { alignItems: 'flex-end' } }, [
        el('label.field.grow', { style: { marginBottom: 0, minWidth: '150px' } }, [el('span', {}, 'Mã lớp'), code]),
        el('label.field.grow', { style: { marginBottom: 0, minWidth: '200px' } }, [el('span', {}, 'Tên lớp'), name]),
        el('button.btn', {
          onclick: async () => {
            try {
              const added = await addClass(code.value, name.value);
              // Giáo viên tự tạo lớp thì lớp đó thuộc về chính thầy/cô
              if (!isAdmin) await assignClassToSelf(added.code);
              toast('Đã thêm lớp ' + added.code, 'ok');
              renderClasses(host, currentUser());
            } catch (e) { toast(e.message, 'bad'); }
          },
        }, 'Thêm lớp'),
      ]),
      el('div.hint', { style: { marginTop: '8px' } }, isAdmin
        ? 'Quản trị viên nhìn thấy và quản lý toàn bộ các lớp.'
        : 'Lớp thầy/cô tự tạo sẽ được gán ngay cho tài khoản của thầy/cô. Muốn xoá lớp thì nhờ quản trị viên.'),
    ]),

    classes.length ? el('div.tbl-wrap', {}, el('table.tbl', {}, [
      el('thead', {}, el('tr', {}, [el('th', {}, 'Mã lớp'), el('th', {}, 'Tên lớp'), el('th', {}, '')])),
      el('tbody', {}, classes.map((c) => el('tr', {}, [
        el('td', {}, el('span.chip', {}, c.code)),
        el('td', {}, c.name),
        el('td', {}, isAdmin ? el('button.btn.btn-plain.btn-sm', {
          onclick: async () => {
            if (!confirm(`Xoá lớp ${c.code}? Học sinh lớp này sẽ không đăng nhập được nữa.`)) return;
            await removeClass(c.code);
            toast('Đã xoá lớp ' + c.code);
            renderClasses(host, user);
          },
        }, '🗑️ Xoá') : ''),
      ]))),
    ])) : el('div.card.empty', {}, [
      el('div.ic', {}, '🏫'),
      el('div.bold', {}, 'Chưa có lớp nào được gán cho thầy/cô'),
    ]),
  );
}

/* ==================================================================== */
/*  Thẻ — Tài khoản giáo viên (chỉ quản trị viên thấy)                  */
/* ==================================================================== */

async function renderTeachers(host) {
  const [teachers, classes] = await Promise.all([listTeachers(), listClasses()]);

  const username = el('input.input', {
    placeholder: 'VD: colan', style: { textTransform: 'lowercase' },
  });
  const name = el('input.input', { placeholder: 'VD: Cô Lan' });
  const password = el('input.input', { placeholder: 'Ít nhất 4 ký tự' });

  // Ô tick chọn lớp cho giáo viên mới
  const picked = new Set();
  const classPicker = el('div.row.wrapf', { style: { gap: '8px' } },
    classes.map((c) => {
      const box = el('input', { type: 'checkbox' });
      box.onchange = () => { box.checked ? picked.add(c.code) : picked.delete(c.code); };
      return el('label.chip.chip-soft', {
        style: { cursor: 'pointer', display: 'inline-flex', gap: '6px', alignItems: 'center' },
        title: c.name,
      }, [box, c.code]);
    }));

  async function submit() {
    try {
      await saveTeacher({
        username: username.value,
        name: name.value,
        password: password.value,
        classes: Array.from(picked),
      });
      toast('Đã tạo tài khoản cho ' + (name.value || username.value), 'ok');
      renderTeachers(host);
    } catch (e) { toast(e.message, 'bad'); }
  }

  clear(host);
  host.append(
    el('div.alert.alert-info', { style: { marginBottom: '16px' } },
      'Mỗi giáo viên có tài khoản riêng và chỉ xem được điểm của những lớp được gán. Quản trị viên xem được tất cả.'),

    el('div.card', { style: { marginBottom: '18px' } }, [
      el('h3', {}, '➕ Thêm giáo viên'),
      el('div.row.wrapf', {}, [
        el('label.field.grow', { style: { minWidth: '160px' } }, [
          el('span', {}, 'Tài khoản đăng nhập'), username,
          el('div.hint', {}, 'Không dấu, không khoảng trắng'),
        ]),
        el('label.field.grow', { style: { minWidth: '160px' } }, [el('span', {}, 'Tên hiển thị'), name]),
        el('label.field.grow', { style: { minWidth: '150px' } }, [el('span', {}, 'Mật khẩu'), password]),
      ]),
      el('div.field', {}, [
        el('span', {}, 'Lớp phụ trách'),
        classes.length ? classPicker
          : el('div.hint', {}, 'Chưa có lớp nào — thêm lớp ở thẻ "Lớp học" trước.'),
      ]),
      el('button.btn', { onclick: submit }, '💾 Tạo tài khoản'),
    ]),

    el('div.sec-title', {}, [el('h2', {}, `👩‍🏫 Danh sách giáo viên (${teachers.length})`), el('div.ln')]),

    teachers.length ? el('div.tbl-wrap', {}, el('table.tbl', {}, [
      el('thead', {}, el('tr', {}, [
        el('th', {}, 'Tài khoản'), el('th', {}, 'Tên hiển thị'),
        el('th', {}, 'Mật khẩu'), el('th', {}, 'Lớp phụ trách'), el('th', {}, ''),
      ])),
      el('tbody', {}, teachers.map((t) => el('tr', {}, [
        el('td', {}, el('span.chip', {}, t.username)),
        el('td.bold', {}, t.name),
        el('td', {}, el('span.small.muted', {}, '•'.repeat(Math.min(10, t.password.length)))),
        el('td', {}, el('div.row.wrapf', { style: { gap: '5px' } },
          (t.classes.length ? t.classes : ['—']).map((c) => el('span.chip.chip-soft', {}, c)))),
        el('td', {}, el('div.row', { style: { gap: '6px' } }, [
          el('button.btn.btn-ghost.btn-sm', {
            onclick: async () => {
              const pw = prompt(`Mật khẩu mới cho ${t.name}:`, '');
              if (pw === null) return;
              try {
                await saveTeacher({ ...t, password: pw });
                toast('Đã đổi mật khẩu', 'ok');
                renderTeachers(host);
              } catch (e) { toast(e.message, 'bad'); }
            },
          }, '🔑 Đổi mật khẩu'),
          el('button.btn.btn-ghost.btn-sm', {
            onclick: async () => {
              const cur = t.classes.join(', ');
              const s = prompt(
                `Lớp mà ${t.name} phụ trách (các mã lớp cách nhau bởi dấu phẩy).\nCác lớp đang có: ${classes.map((c) => c.code).join(', ') || 'chưa có lớp nào'}`,
                cur);
              if (s === null) return;
              const list = s.split(',').map((x) => x.trim().toUpperCase()).filter(Boolean);
              try {
                await saveTeacher({ ...t, classes: list });
                toast('Đã cập nhật lớp phụ trách', 'ok');
                renderTeachers(host);
              } catch (e) { toast(e.message, 'bad'); }
            },
          }, '🏫 Gán lớp'),
          el('button.btn.btn-plain.btn-sm', {
            onclick: async () => {
              if (!confirm(`Xoá tài khoản ${t.username}?`)) return;
              await removeTeacher(t.username);
              toast('Đã xoá tài khoản ' + t.username);
              renderTeachers(host);
            },
          }, '🗑️'),
        ])),
      ]))),
    ])) : el('div.card.empty', {}, [
      el('div.ic', {}, '👩‍🏫'),
      el('div.bold', {}, 'Chưa có giáo viên nào'),
      el('div.small', {}, 'Điền form phía trên để tạo tài khoản đầu tiên.'),
    ]),

    el('div.alert', { style: { marginTop: '16px' } }, CLOUD
      ? '☁️ Tài khoản giáo viên được lưu trên máy chủ nên đăng nhập được từ mọi máy.'
      : '⚠️ Đang ở chế độ ngoại tuyến: tài khoản giáo viên chỉ lưu trên chính máy này. Bật Supabase ở thẻ "Kết nối" để giáo viên đăng nhập được từ máy khác.'),
  );
}

/* ==================================================================== */
/*  Thẻ 3 — Bài học (tải file Word/PDF)                                 */
/* ==================================================================== */

async function renderLessons(host) {
  const lessons = await listLessons();
  const preview = el('div');

  const title = el('input.input', { placeholder: 'VD: Ôn tập bài 6–10' });
  const code = el('input.input', { placeholder: 'VD: TN1101', style: { textTransform: 'uppercase' } });
  const subtitle = el('input.input', { placeholder: 'VD: Gia đình · Số đếm · Màu sắc' });
  const textarea = el('textarea.input', {
    rows: 7,
    placeholder: 'Hoặc dán trực tiếp nội dung vào đây.\n\nMỗi dòng 1 từ, có thể viết:\n你好 | nǐ hǎo | xin chào\nhoặc chỉ cần: 你好, 再见, 老师\n(hệ thống sẽ tự tra pinyin và nghĩa cho từ thông dụng)',
  });
  const fileInput = el('input', {
    type: 'file',
    accept: '.docx,.pdf,.txt,.md,.csv',
    style: { display: 'none' },
  });

  let parsed = null;

  async function handleText(text) {
    const res = parseVocab(text);
    if (!res.words.length && !res.sentences.length) {
      toast('Không tìm thấy chữ Hán nào trong nội dung này', 'bad');
      return;
    }
    parsed = res;
    drawPreview();
  }

  function drawPreview() {
    const missing = parsed.words.filter((w) => !w.vi).length;
    clear(preview);
    preview.append(
      el('div.sec-title', {}, [el('h2', {}, `👀 Xem lại trước khi lưu (${parsed.words.length} từ, ${parsed.sentences.length} câu)`), el('div.ln')]),
      missing
        ? el('div.alert', { style: { marginBottom: '12px' } },
            `⚠️ Có ${missing} từ chưa có nghĩa — thầy/cô điền giúp vào ô "Nghĩa tiếng Việt" bên dưới. Từ để trống sẽ không được đưa vào game.`)
        : el('div.alert.alert-ok', { style: { marginBottom: '12px' } },
            '✅ Tất cả các từ đã có pinyin và nghĩa. Thầy/cô kiểm tra lại rồi bấm Lưu.'),

      el('div.tbl-wrap', { style: { maxHeight: '460px', overflowY: 'auto' } },
        el('table.tbl', {}, [
          el('thead', {}, el('tr', {}, [
            el('th', {}, 'Hán tự'), el('th', {}, 'Pinyin'), el('th', {}, 'Nghĩa tiếng Việt'),
            el('th', {}, 'Nhóm'), el('th', {}, ''),
          ])),
          el('tbody', {}, parsed.words.map((w, i) => el('tr', {}, [
            el('td', {}, el('span.hz', { style: { fontSize: '1.4rem' } }, w.hz)),
            el('td', {}, el('input.input', {
              value: w.py, style: { padding: '7px 10px', minWidth: '110px' },
              oninput: (e) => { parsed.words[i].py = e.target.value; },
            })),
            el('td', {}, el('input.input', {
              value: w.vi, placeholder: 'nhập nghĩa...',
              style: { padding: '7px 10px', minWidth: '180px', borderColor: w.vi ? '' : 'var(--red-500)' },
              oninput: (e) => { parsed.words[i].vi = e.target.value; },
            })),
            el('td', {}, el('input.input', {
              value: w.tag || '', style: { padding: '7px 10px', minWidth: '110px' },
              oninput: (e) => { parsed.words[i].tag = e.target.value; },
            })),
            el('td', {}, el('button.btn.btn-plain.btn-sm', {
              onclick: (e) => { parsed.words.splice(i, 1); drawPreview(); },
            }, '🗑️')),
          ]))),
        ])),

      parsed.sentences.length ? el('div', { style: { marginTop: '16px' } }, [
        el('h3', {}, 'Mẫu câu (dùng cho game Sắp xếp câu)'),
        el('div.review-list', {}, parsed.sentences.map((s, i) => el('div.review-item', {}, [
          el('div.hz', { style: { fontSize: '1.25rem', minWidth: '150px' } }, s.hz),
          el('input.input.grow', {
            value: s.vi, placeholder: 'Nghĩa tiếng Việt của câu...',
            style: { padding: '7px 10px' },
            oninput: (e) => { parsed.sentences[i].vi = e.target.value; },
          }),
          el('button.btn.btn-plain.btn-sm', {
            onclick: () => { parsed.sentences.splice(i, 1); drawPreview(); },
          }, '🗑️'),
        ]))),
      ]) : null,

      el('div.row', { style: { marginTop: '18px' } }, [
        el('button.btn.btn-lg', {
          onclick: async () => {
            const good = parsed.words.filter((w) => w.hz && w.vi);
            if (!good.length) return toast('Cần ít nhất 1 từ có nghĩa tiếng Việt', 'bad');
            if (good.length < 4) return toast('Cần ít nhất 4 từ để tạo được câu hỏi trắc nghiệm', 'bad');
            const lesson = buildLesson({
              title: title.value || 'Bài học mới',
              code: code.value.toUpperCase(),
              subtitle: subtitle.value,
              words: good,
              sentences: parsed.sentences.filter((s) => s.hz && s.vi),
            });
            await saveLesson(lesson);
            toast(`Đã lưu "${lesson.title}" với ${good.length} từ`, 'ok');
            parsed = null;
            renderLessons(host);
          },
        }, '💾 Lưu bài học'),
        el('button.btn.btn-ghost', {
          onclick: () => { parsed = null; clear(preview); },
        }, 'Huỷ'),
      ]),
    );
    preview.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  fileInput.onchange = async () => {
    const f = fileInput.files[0];
    if (!f) return;
    toast('Đang đọc file...');
    try {
      const text = await extractText(f);
      textarea.value = text;
      if (!title.value) title.value = f.name.replace(/\.[^.]+$/, '');
      await handleText(text);
    } catch (e) {
      toast(e.message, 'bad');
      console.error(e);
    }
    fileInput.value = '';
  };

  const dropZone = el('div.card', {
    style: {
      border: '2.5px dashed var(--line)', textAlign: 'center', cursor: 'pointer',
      background: 'rgba(255,255,255,.6)',
    },
    onclick: () => fileInput.click(),
    ondragover: (e) => { e.preventDefault(); dropZone.style.borderColor = 'var(--orange-500)'; },
    ondragleave: () => { dropZone.style.borderColor = ''; },
    ondrop: async (e) => {
      e.preventDefault();
      dropZone.style.borderColor = '';
      const f = e.dataTransfer.files[0];
      if (!f) return;
      fileInput.files = e.dataTransfer.files;
      fileInput.onchange();
    },
  }, [
    el('div', { style: { fontSize: '2.6rem' } }, '📄'),
    el('div.bold', {}, 'Kéo thả file vào đây hoặc bấm để chọn'),
    el('div.small.muted', {}, 'Hỗ trợ .docx (Word), .pdf, .txt, .csv'),
  ]);

  clear(host);
  host.append(
    el('div.card', { style: { marginBottom: '18px' } }, [
      el('h3', {}, '➕ Thêm bài học mới'),
      el('div.row.wrapf', {}, [
        el('label.field.grow', { style: { minWidth: '200px' } }, [el('span', {}, 'Tên bài'), title]),
        el('label.field', { style: { minWidth: '140px' } }, [el('span', {}, 'Mã lớp/giáo trình'), code]),
      ]),
      el('label.field', {}, [el('span', {}, 'Mô tả ngắn'), subtitle]),
      dropZone,
      fileInput,
      el('div.row', { style: { margin: '16px 0 8px' } }, [
        el('div.ln', { style: { flex: 1, height: '1px', background: 'var(--line)' } }),
        el('span.small.muted', {}, 'hoặc'),
        el('div.ln', { style: { flex: 1, height: '1px', background: 'var(--line)' } }),
      ]),
      el('label.field', {}, [el('span', {}, 'Dán văn bản'), textarea]),
      el('button.btn.btn-block', {
        onclick: () => {
          if (!textarea.value.trim()) return toast('Chưa có nội dung', 'bad');
          handleText(textarea.value);
        },
      }, '🔍 Phân tích nội dung'),
    ]),

    preview,

    el('div.sec-title', {}, [el('h2', {}, '📚 Các bài hiện có'), el('div.ln')]),
    el('div.game-grid', {}, lessons.map((l) => el('div.card', {}, [
      el('div.row-between', {}, [
        el('div', {}, [
          el('h3', { style: { marginBottom: '2px' } }, `${l.emoji || '📘'} ${l.title}`),
          el('div.small.muted', {}, l.subtitle || ''),
        ]),
        l.custom ? el('button.btn.btn-plain.btn-sm', {
          onclick: async () => {
            if (!confirm(`Xoá bài "${l.title}"?`)) return;
            await deleteLesson(l.id);
            toast('Đã xoá');
            renderLessons(host);
          },
        }, '🗑️') : el('span.chip.chip-soft', {}, 'Mặc định'),
      ]),
      el('div.row.wrapf', { style: { marginTop: '10px' } }, [
        el('span.chip.chip-soft', {}, `${l.words.length} từ`),
        el('span.chip.chip-soft', {}, `${(l.sentences || []).length} câu`),
        l.code ? el('span.chip', {}, l.code) : null,
      ]),
    ]))),
  );
}

/* ==================================================================== */
/*  Thẻ 4 — Kết nối Supabase                                            */
/* ==================================================================== */

async function renderCloud(host) {
  clear(host);
  const status = el('div.card.center', {}, 'Đang kiểm tra kết nối...');
  host.append(status);

  const r = await pingCloud();
  clear(status);
  status.classList.remove('center');
  status.append(
    el('div.row', {}, [
      el('div', { style: { fontSize: '2.2rem' } }, r.ok ? '✅' : '⚠️'),
      el('div', {}, [
        el('h3', { style: { marginBottom: '2px' } }, r.ok ? 'Đã kết nối máy chủ' : 'Chưa kết nối máy chủ'),
        el('div.small.muted', {}, r.msg),
      ]),
    ])
  );

  /* --- Ô nhập Supabase ngay trên web ------------------------------- */
  const urlIn = el('input.input', {
    placeholder: 'https://abcxyz.supabase.co',
    value: CONFIG.supabase.url || '',
  });
  const keyIn = el('input.input', {
    placeholder: 'anon public key (chuỗi dài bắt đầu bằng eyJ...)',
    value: CONFIG.supabase.anonKey || '',
  });
  const codeBox = el('pre.codebox', {}, '');

  function refreshCode() {
    codeBox.textContent =
      `  supabase: {\n    url: '${urlIn.value.trim()}',\n    anonKey: '${keyIn.value.trim()}',\n  },`;
  }
  urlIn.oninput = refreshCode;
  keyIn.oninput = refreshCode;
  refreshCode();

  host.append(
    el('div.card', { style: { marginTop: '16px' } }, [
      el('h3', {}, r.ok ? '🎉 Mọi thứ đã sẵn sàng' : '🔧 Bật lưu điểm tập trung (miễn phí, ~5 phút)'),

      r.ok
        ? el('p', {}, 'Điểm của học sinh ở mọi thiết bị đều được lưu về đây, và phòng Kahoot chơi được nhiều máy cùng lúc.')
        : el('div', {}, [
            el('p', {}, 'Chỉ tạo bảng trong Supabase thôi là CHƯA đủ — website còn cần biết địa chỉ và khoá của Supabase thì mới kết nối được. Làm theo 3 bước:'),
            el('ol', {}, [
              el('li', {}, 'Supabase → SQL Editor → dán file supabase/schema.sql → Run (bước này thầy/cô đã làm nếu đã thấy bảng teachers)'),
              el('li', {}, 'Supabase → Project Settings → API → chép "Project URL" và "anon public key"'),
              el('li', {}, 'Dán 2 giá trị đó vào 2 ô ngay bên dưới'),
            ]),
          ]),

      el('div.row.wrapf', {}, [
        el('label.field.grow', { style: { minWidth: '260px' } }, [el('span', {}, 'Project URL'), urlIn]),
      ]),
      el('label.field', {}, [el('span', {}, 'anon public key'), keyIn]),

      el('div.row.wrapf', {}, [
        el('button.btn', {
          onclick: async () => {
            const url = urlIn.value.trim().replace(/\/$/, '');
            const key = keyIn.value.trim();
            if (!url || !key) return toast('Cần điền cả 2 ô', 'bad');
            localStorage.setItem('nz_supabase', JSON.stringify({ url, anonKey: key }));
            toast('Đã lưu — đang tải lại để kết nối...', 'ok');
            setTimeout(() => location.reload(), 700);
          },
        }, '💾 Lưu & kiểm tra kết nối'),
        CONFIG.supabaseFromBrowser ? el('button.btn.btn-ghost', {
          onclick: () => {
            localStorage.removeItem('nz_supabase');
            toast('Đã xoá cấu hình trên máy này');
            setTimeout(() => location.reload(), 700);
          },
        }, 'Xoá cấu hình trên máy này') : null,
      ]),

      CONFIG.supabaseFromBrowser ? el('div.alert', { style: { marginTop: '12px' } }, [
        el('div.bold', {}, '⚠️ Mới chỉ chạy trên máy này'),
        el('div.small', {}, 'Thầy/cô đang dùng cấu hình lưu tạm trong trình duyệt của máy này. Máy của học sinh và của giáo viên khác vẫn chưa kết nối. Để cả trung tâm dùng chung, hãy chép đoạn dưới đây vào file public/js/config.js (thay cho phần supabase đang có), rồi git push để website tự cập nhật:'),
        codeBox,
      ]) : el('div', { style: { marginTop: '12px' } }, [
        el('div.small.muted', {}, 'Đoạn cần dán vào public/js/config.js (thay cho phần supabase đang có), sau đó git push:'),
        codeBox,
      ]),

      el('div.alert.alert-info', { style: { marginTop: '12px' } },
        '💡 "anon public key" là khoá công khai, được thiết kế để nhúng thẳng vào website tĩnh — dán vào config.js là đúng cách. Tuyệt đối KHÔNG dùng "service_role key".'),
    ])
  );
}
